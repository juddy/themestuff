#! /bin/sh
# installer for itomatOS Eterm theme
cp -R itomatOS ~/.Eterm/themes/
#alias Eterm='Eterm -t itomatOS'

echo "I suggest creating alias for Eterm that calls the itomatOS theme."
echo "   alias Eterm='Eterm -t itomatOS'"
echo 
echo
echo "If you want to install for users other than yourself:"
echo "   cp -R itomatOS /usr/share/Eterm/themes/"
echo
echo

