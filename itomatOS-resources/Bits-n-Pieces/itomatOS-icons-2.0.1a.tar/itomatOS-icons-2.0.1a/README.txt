This is an Alpha set of the itomatOS icons, Version 2.0.1a.

I'm looking for feedback on this one; bad contrast, wonky shadows (I know there are a few),
bad icons, etc.

I am experimenting with conversion processes, we'll call this 'Process S'.

48, 64, and 128 px icons have been included this time around, and they will be in the final release.

Thx,
itomato