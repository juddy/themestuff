for i in ./pix/bar_horizontal_1.png ./pix/bar_horizontal_3.png ./pix/bar_vertical_1.png ./pix/bg.png ./pix/button_arrow_down_1.png ./pix/button_arrow_down_2.png ./pix/button_arrow_up_1.png ./pix/button_arrow_up_2.png 
do
xzgv $i &
done
