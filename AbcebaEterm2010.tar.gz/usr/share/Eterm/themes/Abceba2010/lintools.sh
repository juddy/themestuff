#!/bin/bash
# lintools.sh
# Linux Toolbox script
# Addon for Abceba2010 Eterm theme

# Define functions

#################################
ping_host(){
#################################

dialog --inputbox "Host to ping?" 0 0 2>/tmp/phost
ping -c4 $(cat /tmp/phost)

}
#################################


#################################
google(){
#################################

links2 http://google.com 
}
#################################




#################################
do_menu(){
#################################

#################################
#       --radiolist text height width list-height  [ tag item status ] ...
#              A  radiolist box is similar to a menu box.  The only difference is that you can indicate which entry is
#              currently selected, by setting its status to on.
#
#              On exit, the name of the selected item is written to dialog's output.
#################################

dialog --radiolist "Select option" 30 50 2  ping_host ping_host on google google off 2>/tmp/menopt
$(cat /tmp/menopt)
}
#################################

############################################################

# Execution

do_menu
